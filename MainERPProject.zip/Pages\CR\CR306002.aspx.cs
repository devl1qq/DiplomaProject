﻿using System;

public partial class Page_CR306002 : PX.Web.UI.PXPage
{
    protected void Page_Init(object sender, EventArgs e)
    {
    }
}
