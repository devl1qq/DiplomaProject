﻿using System;

public partial class Page_CR306001 : PX.Web.UI.PXPage
{
    protected void Page_Init(object sender, EventArgs e)
    {
    }
}
