﻿using System;

public partial class Page_SO301005 : PX.Web.UI.PXPage
{
    protected void Page_Init(object sender, EventArgs e)
    {
    }
}
