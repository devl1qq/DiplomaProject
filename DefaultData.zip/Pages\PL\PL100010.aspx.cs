﻿using System;
using System.Configuration;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using GoodsInLabel.Graph;
using PX.Web.UI;
using PX.Web.Controls;

public partial class Page_PL100010 : PX.Web.UI.PXPage
{
    protected void edFormulaGenerateFields(object sender, PXCallBackEventArgs e)
    {
        ArcZplTemplateMaint graph = this.ds.DataGraph as ArcZplTemplateMaint;
        if (graph == null) return;

        IEnumerable<string> fields = graph.GenerateEntitiesFields();

        e.Result = fields.Any()
            ? fields.Aggregate((acc, next) => $"{acc};{next}")
            : "<EMPTY>";
    }
}