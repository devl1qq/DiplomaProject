﻿using System;

public partial class Page_IN306000 : PX.Web.UI.PXPage
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
}